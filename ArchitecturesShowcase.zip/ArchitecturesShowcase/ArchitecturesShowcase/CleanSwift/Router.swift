//
//  Router.swift
//  ArchitecturesShowcase
//
//  Created by Dmitriy Ignatenko on 11/17/23.
//

import Foundation


import UIKit

protocol RoutingLogic {
    func goToStart()
}

class Router: RoutingLogic {
    weak var viewController: UIViewController?

    func goToStart() {
        viewController?.present(MVCViewController(), animated: false)
    }
}
